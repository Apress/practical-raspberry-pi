#!/bin/bash
# Description : A simple bash script to read the pressure mat status
# Author : Brendan Horan

# Start a loop that can't end
  while true; do

# Get the value of the GPIO Pin
  MATSTAT=`cat /sys/class/gpio/gpio4/value`
  
    if [ $MATSTAT == 1 ]
    then
# Sleep for 2 seconds if status=1
      sleep 2
    else
# Echo out text if status=0
      echo "Ouch! Don't step on me!!"
    fi
  done
