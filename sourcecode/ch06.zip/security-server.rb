#!/usr/bin/ruby
# Description : Ruby webrick html server and reader loop
#  this app will run out of one directory self contained
#  ensure security-server.rb and reader-loop.rb are in the same dir
# Author : Brendan Horan

# Include
require 'webrick'
include WEBrick

# Set up the webrick
  dir = Dir::pwd
  port = "80"
  access_log_stream = File.open('access.log', 'w')
  access_log = [ [ access_log_stream, AccessLog::COMBINED_LOG_FORMAT ] ]

  puts "Acess at :-"
  puts "URL: http://#{Socket.gethostname}:#{port}"

# Start the background reader loop
  puts "Starting Reader Loop on pid :-"
  pipe = IO.popen("./reader-loop.rb")
  puts pipe.pid

  server = HTTPServer.new(
    :Port            => port,
    :DocumentRoot    => dir,
    :AccessLog       => access_log
  )

# trap exit saftly and start the webrick
  trap("INT"){ server.shutdown }
  puts "Running.. Hit Ctrl+c to stop."
  server.start
