#!/usr/bin/ruby
# Description : Ruby webrick html server and reader loop
#  this app will run out of one directory self contained
# Author : Brendan Horan


# Start a loop that should not end
  while true do

# Open index.html for writing and the two value files for reading
    index = File.new("index.html", "w+")
    mat = File.open("/sys/class/gpio/gpio4/value")
    pir = File.open("/sys/class/gpio/gpio17/value")

# Set the html page to auto refresh every second
    index.puts "<HTML><HEAD> <meta http-equiv='refresh' content='1'></HEAD>"

# get the status of the pressure mat
    while line = mat.gets do
      index.puts "<p>Mat status :-</p>"
      index.puts line
    end
    mat.close

# get the status of the PIR
    while line = pir.gets do
      index.puts "<p>PIR status :-</p>"
      index.puts line
    end
    pir.close

# Close index.html and sleep to allow security-server.rb to read
    index.close
    sleep 2
  end
