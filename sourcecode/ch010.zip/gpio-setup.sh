#!/bin/bash
# Description : Set up GPIO pins, exit if they are already one
#  GPIO 4 is the ON switch
#  GPIO 17 is the OFF switch
# Author : Brendan Horan

  function check {
  if [ -e "/sys/class/gpio/gpio4" ]
  then
    exit 
  fi
  }

  function exportpgio {
# Export the GPIO pins
  echo 4 > /sys/class/gpio/export
  echo 17 > /sys/class/gpio/export
  }

  function direction {
# Set the GPIO pins to be output's
  echo out > /sys/class/gpio/gpio4/direction
  echo out > /sys/class/gpio/gpio17/direction
  }

# set the pins to low to start with
  function setlow {
  echo 0 > /sys/class/gpio/gpio4/value
  echo 0 > /sys/class/gpio/gpio17/value
  }

check
exportgpio
direction
setlow
