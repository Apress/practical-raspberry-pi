#!/bin/bash
# Description : command line tool to turn on/off a device
#  You must have the GPIO pins set up first. use gpio-setup.sh
# Use : ./cmd-ctl.sh on|off
# Author : Brendan Horan

# Turn on 
  function on {
  /bin/echo 1 > /sys/class/gpio/gpio4/value
  sleep 1
  /bin/echo 0 > /sys/class/gpio/gpio4/value
  # Create a file to indicate current outlet state
  /bin/echo power-on > outlet-status
  }

# Turn off
  function off {
  /bin/echo 1 > /sys/class/gpio/gpio17/value
  sleep 1
  /bin/echo 0 > /sys/class/gpio/gpio17/value
  # Create a file to indicate current outlet state
  /bin/echo power-on > outlet-status
  }

# What shall I do ?
$1
