#!/bin/sh

# Autostart for ntp
/usr/sbin/ntpd -c /storage/.config/ntp.conf

