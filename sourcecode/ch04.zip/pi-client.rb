#!/usr/bin/ruby
# Description : A simple script to talk to the LCDd server
# Author : Brendan Horan


# Use the net telnet functions
require 'net/telnet'

# Trap crtl-c nicely
trap("INT") { puts " Shutting down client."; exit}

# Create a new connection to the Pi
  pilcd = Net::Telnet::new(

    # Change this IP to your Pi's IP
    "Host" => "192.168.0.199",
    "Port" => 13666,

    # We are not a real telnet client
    "Telnetmode" => false,

    # Don't time out we don't care about responses
    "Timeout" => false)

  # Send the hello command to start communicating
  pilcd.puts("hello")

  # Add an Screen and set it to foreground
  pilcd.puts("screen_add s1")
  pilcd.puts("screen_set s1 -priority 1")

  # Create two widgets for each row
  pilcd.puts("widget_add s1 w1 title")
  pilcd.puts("widget_add s1 w2 string")

  # Write to each widget to each row of the LCD
  pilcd.puts("widget_set s1 w1 {I2C LCD}")
  pilcd.cmd("widget_set s1 w2 4 2 {MOAR Pi !}") { |c| print c }
